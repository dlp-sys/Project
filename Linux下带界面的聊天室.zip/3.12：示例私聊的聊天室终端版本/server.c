#include <stdio.h>
#include <string.h>
#include "unistd.h"
#include "sys/types.h"
#include "stdlib.h"
#include "stdint.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#define MYSQL_HOST "localhost"
#define MYSQL_USER "root"
#define MYSQL_PASSWD "1"
#define MYSQL_DB "xyddb"
#define MYSQL_TABLENAME "xyd_chat_table"
char net_namelist[1024][32]={0};//1024 个网名空间

void client_data_handle(int ckd);
int xyd_read(int ckd, uint8_t *data, int len);
int xyd_write(int ckd, uint8_t *data, int len);
struct client_msg{
    int flag;//0->群聊消息  1->私聊消息
    char aloneobj_name[32];//私聊对象的名字 flag=0无效
    char sendname[32];//发送者的名字
    char msg[1024];//发送的实际信息
};
fd_set readfds,lockfds;//两个表
int MAX =0;
int oneline_count =0;//在线个数
int skd ;
int main(int argc,char * argv[])
{
 
   
//1：创建套接子
    skd = socket(AF_INET, SOCK_STREAM, 0);
//2：释放套接子的地址和端口号
    int opt =1;
    setsockopt(skd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    setsockopt(skd, SOL_SOCKET, 15, &opt, sizeof(opt));
//3：绑定自身IP地址和端口号
    struct sockaddr_in servaddr;
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(33344);
    servaddr.sin_addr.s_addr = 0;
    bind(skd, (struct sockaddr *)&servaddr, sizeof(servaddr));
//4: 监听最大连接数
    listen(skd,64);
//5： select 监控整个系统
    FD_ZERO(&lockfds);//清空整个表
    FD_SET(skd, &lockfds);//服务器套接子放到表里面
    MAX = skd;
    while(1)
    {
        readfds = lockfds;
        //主线程阻塞在 select  直到 有套接子 产生数据！
        select(MAX+1, &readfds, NULL, NULL, NULL);
        for(int i=3;i<=MAX;i++)//看看是谁还在表里面
        {
            if(FD_ISSET(i, &readfds))
            {
                if(i == skd)//服务器出现了变化！
                {
                    struct sockaddr_in clientaddr;
                    socklen_t clientaddr_len = sizeof(clientaddr);
                    //接受客户连接
                    int ckd = accept(skd, (struct sockaddr *)&clientaddr, &clientaddr_len);
                    //6
                    //上线后读取该客户的临时网名
                    // 空间很浪费
                    xyd_read(ckd,net_namelist[ckd],32);//读取网名
                    //要把他添加到表里面！
                    FD_SET(ckd, &lockfds);
                    if(ckd > MAX) MAX = ckd;
                    oneline_count++;
                    printf("当前在线人数：%d\n", oneline_count);
                }else//客户端出现了变化！
                {
                    //一定有客户发来消息！
                    client_data_handle(i);
                }
            }
        }
    }
   

}

/**

 */
void client_data_handle(int ckd)
{
    struct client_msg recvclientmsg;
    //处理客户端发来的消息->就是一个结构体->所谓的协议！
    int ret = xyd_read(ckd,(uint8_t *)&recvclientmsg,sizeof(recvclientmsg));
    if(ret == 0)//客户离线
    {
        //关闭套接字
        close(ckd);
        FD_CLR(ckd,&lockfds);//把该文件从表里面清除！
    }
    //这是群聊消息还是私聊消息！
    if(recvclientmsg.flag == 0)//群聊消息
    {
        //所有的客户转发一遍
        for(int i = 4;i<=MAX;i++)
        {
            if(FD_ISSET(i,&lockfds) && i!=ckd && i!=skd)//套接字在表里面且不是我自己
            {
                xyd_write(i,(uint8_t *)&recvclientmsg,sizeof(recvclientmsg));
                //接到什么我给你转发什么！
            }
        }
    }else if(recvclientmsg.flag == 1)//私聊消息
    {   
        //找到私聊对象-> recvclientmsg.aloneobj_name
        recvclientmsg.aloneobj_name;
        //找到这个名字对应的套接字！
        //套接字和名字现在有关系吗?
        //要么有数据库->通过数据库找到
        //要么拥护在连接的时候绑定客户的名字!
        for(int i =4;i<=MAX;i++)//全部遍历找到该用户网名 跟私聊对象一致
        {
            //套接字不是服务器， 传入私聊对象 匹配某个套接字绑定网名！
            if(i!=skd && (strcmp(net_namelist[i], recvclientmsg.aloneobj_name)==0))
            {   
                xyd_write(i,(uint8_t *)&recvclientmsg,sizeof(recvclientmsg));
                break;
            }
        }
        //核心思想：
        /**
         *  1： 如何通用一个已知条件(userID 名字) 找到另一个条件(套接字)
         *      大部分通过 数据库！
         *  2： 通信两边的协议-> 自定义你感觉比较方便的结构体
         * 
         * 
         */

    }
}