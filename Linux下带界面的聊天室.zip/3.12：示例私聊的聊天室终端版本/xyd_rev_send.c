#include <stdio.h>
#include <string.h>
#include "unistd.h"
#include "sys/types.h"
#include "stdlib.h"
#include "stdint.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>


int xyd_read(int ckd, uint8_t *data, int len)
{
    uint8_t * tmpp = data;
    int readlen = 0;
    int ret = 0;
    while(1)
    {
        ret = recv(ckd,tmpp,len-readlen,0);
        if(ret <=0)
        {
            return ret;
        }
        readlen +=ret;
        tmpp+=ret;
        if(readlen == len)
        {
            return readlen;
        }
    }
}

int xyd_write(int ckd, uint8_t *data, int len)
{
    uint8_t * tmpp = data;
    int writelen = 0;
    int ret = 0;
    while(1)
    {
        ret = send(ckd,tmpp,len-writelen,0);
        if(ret <=0)
        {
            return ret;
        }
        writelen +=ret;
        tmpp+=ret;
        if(writelen == len)
        {
            return writelen;
        }
    }
}