#include <stdio.h>
#include <string.h>
#include "unistd.h"
#include "sys/types.h"
#include "stdlib.h"
#include "stdint.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include "pthread.h"
#define MYSQL_HOST "localhost"
#define MYSQL_USER "root"
#define MYSQL_PASSWD "1"
#define MYSQL_DB "xyddb"
#define MYSQL_TABLENAME "xyd_chat_table"
char self_name[32]={0};
struct client_msg{
    int flag;//0->群聊消息  1->私聊消息
    char aloneobj_name[32];//私聊对象的名字 flag=0无效
    char sendname[32];//发送者的名字
    char msg[1024];//发送的实际信息

};
void * recv_client_data(void * arg);
int ckd ;
int xyd_read(int ckd, uint8_t *data, int len);
int xyd_write(int ckd, uint8_t *data, int len);
char * get_alone_obj_name_handle(char * str,char * retmsg);
int main(int argc,char * argv[])
{

    //4:直接写个while不断和服务器通信
    printf("请为本次聊天起个网名\r\n\t\t");
    gets(self_name);

//1：创建套接子
    ckd = socket(AF_INET, SOCK_STREAM, 0);
//2：释放套接子的地址和端口号
    int opt =1;
    setsockopt(ckd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    setsockopt(ckd, SOL_SOCKET, 15, &opt, sizeof(opt));
//3:连接服务器
   
    struct sockaddr_in connect_servaddr;
    connect_servaddr.sin_family = AF_INET;
    connect_servaddr.sin_port = htons(33344);
    connect_servaddr.sin_addr.s_addr = inet_addr("139.196.139.147");
    int ret=connect(ckd, (struct sockaddr *)&connect_servaddr, sizeof(connect_servaddr));
    if(ret < 0)
    {
        printf("连接服务器失败、服务器未开启！\r\n");
        exit(0);
    }


    //4.1：上线后 获取的网名发送给服务器。让服务器做个关系绑定！
    xyd_write(ckd,self_name,32);
    
    char str[1024]={0};
    char msg[1024]={0};
    char * name = NULL;
    struct client_msg sendmsg;
    strcpy(sendmsg.sendname,self_name);//赋值名字
    pthread_t pd;
    pthread_create(&pd,NULL,recv_client_data,NULL);
    while(1)
    {   
        //4.1：从终端获取要发送的数据/文本->自动判定
        printf("请输入你要发送的数据！\r\n\t\t\t:");
        memset(str,0,1024);
        gets(str);

        //这一部分也可以放到服务器做处理
        //发送私聊消息！->区分 以特殊符号 @作为区分！
        name = get_alone_obj_name_handle(str,msg);
        if(name == NULL)
        {
            printf("这是群聊消息！\r\n");
            sendmsg.flag = 0;//群聊消息
            strcpy(sendmsg.msg,str);//消息本体 str
        }else 
        {
            printf("私聊消息 name == %s\r\n",name);
            printf("私聊消息体 == %s\r\n",msg);
            sendmsg.flag = 1;//群聊消息
            strcpy(sendmsg.msg,msg);//消息本体 str
            strcpy(sendmsg.aloneobj_name,name);//私聊对象
        }
        xyd_write(ckd,&sendmsg,sizeof(sendmsg));
       

    }
    
    return 0;
}

//获取私聊对象的名字
//如果传入的消息不是私聊信息，返回NULL 
char * get_alone_obj_name_handle(char * str,char * retmsg)
{
    static char name[32]={0};
    char * tmpp = str;
    int i =0;
    memset(name,0,32);
    if(*tmpp == '@')
    {
        tmpp++;
        while(1)
        {
            if(*tmpp ==':' && i==0)
            {
                return NULL;//不成立！  @:
            }
            name[i] = *tmpp;//一个字符一个字符取出来
            i++;
            tmpp++;
            if(*tmpp ==':')//获取名字结束了！
            {
                printf("name == %s\r\n",name);
                break;
            }
        }
        tmpp++;
        i=0;
        while(*tmpp!='\0')
        {
            retmsg[i++] = *tmpp;
            tmpp++;
        }
    }else 
    {
        return NULL;
    }
    return name;
}



void * recv_client_data(void * arg)
{
    struct client_msg rcvdata;
    while(1)
    {
        xyd_read(ckd,&rcvdata,sizeof(rcvdata));
        if(rcvdata.flag == 0)
        {
            printf("%s:%s\r\n",rcvdata.sendname,rcvdata.msg);
        }else
        {
            printf("%s:%s(此条消息只有你能看到)\r\n",rcvdata.sendname,rcvdata.msg);
        }
       
    }
}