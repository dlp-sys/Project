﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace 窗体
{
    public partial class ManageForm : Form
    {
        public ManageForm()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel3_Click(object sender, EventArgs e)
        {
     
        }

        private void 科目管理CToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }


        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            InsertForm form3 = new InsertForm();
            form3.Show();
            form3.MdiParent = this;
        }

        private void toolStripLabel4_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripLabel5_Click(object sender, EventArgs e)
        {
           
        }

        private void Form2_Load(object sender, EventArgs e)
        {


        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            //Form28 f4 = new Form28();
            //f4.ShowDialog();
            this.Visible = true;
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripLabel6_Click(object sender, EventArgs e)
        {
            this.Visible = false;
           // Form17 f4 = new Form17();
            //f4.ShowDialog();
            this.Visible = true;
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
           
            DialogResult dt= MessageBox.Show("确定是否退出？","系统提示",MessageBoxButtons.OKCancel);
            if (dt == DialogResult.OK)
            {
                this.Close();
            }
            else
            { 
            
            }
        }

        private void ManageForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void toolStripProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            cjgl f4 = new cjgl();
            f4.ShowDialog();
            this.Visible = true;
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            tjjsxx f4 = new tjjsxx();
            f4.ShowDialog();
            this.Visible = true;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            InsertForm form3 = new InsertForm();
            form3.Show();
            form3.MdiParent = this;
        }

        private void toolStripButton2_Click_1(object sender, EventArgs e)
        {
            InsertForm form3 = new InsertForm();
            form3.Show();
            form3.MdiParent = this;
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
