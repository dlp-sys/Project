﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.OleDb;

namespace 窗体
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            string wa;
            OleDbConnection a1 = new OleDbConnection();
            OleDbCommand a2 = new OleDbCommand();
            //数据库连接
            a1.ConnectionString = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source= 学生信息管理数据库.accdb";
            a1.Open();
            //在数据库中查找对应 的用户名和密码
            wa = "Select * from 用户表 where 用户名='" + txbname.Text.Trim() + "'and 密码='" + txbpwd.Text.Trim() + "'and 角色='" + cmbLeixin.Text.Trim() + "'";
            a2.CommandText = wa;
            a2.Connection = a1;
            a2.ExecuteScalar();
            //获取到数据证明输入账号正确
            if (null != a2.ExecuteScalar())
            {
                //判断账户类型是否为学生
                if (cmbLeixin.Text == "学生")
                {
                    MessageBox.Show("欢迎进入信息管理系统学生端！", "登录成功！", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Visible = false;
                    StudentForm student = new StudentForm();  //学生端
                    student.ShowDialog();
                    this.Visible = true;
                }
                else if (cmbLeixin.Text == "管理员")
                {
                    MessageBox.Show("欢迎进入后台管理模式！", "登录成功！", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Visible = false;
                    ManageForm manage = new ManageForm();
                    manage.ShowDialog();
                    this.Visible = true;
                }
            }
            else if (txbname.Text == "" || txbpwd.Text == "")
            {
                MessageBox.Show("用户名或密码不能为空！");
            }
            else  //账户或者密码错误
            {
                MessageBox.Show("登录失败！请输入正确的用户名、密码和角色！", "警告！", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            RegisterForm f2 = new RegisterForm();
            f2.ShowDialog();
            this.Visible = true;
        }
    }
}
