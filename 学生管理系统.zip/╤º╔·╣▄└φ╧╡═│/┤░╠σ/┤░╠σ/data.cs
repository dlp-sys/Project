﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 窗体
{
    internal class data
    {
        //进行数据库连接集成，后续就不用每个From都写数据库连接语句
        public static string mystr = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source= 学生信息管理数据库.accdb";
    }
}
